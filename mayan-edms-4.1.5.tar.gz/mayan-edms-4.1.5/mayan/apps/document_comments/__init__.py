default_app_config = 'mayan.apps.document_comments.apps.DocumentCommentsApp'
