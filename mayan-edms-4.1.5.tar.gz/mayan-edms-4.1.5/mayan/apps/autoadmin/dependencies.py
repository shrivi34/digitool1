from mayan.apps.dependencies.classes import PythonDependency

PythonDependency(
    module=__name__, name='django-solo', version_string='==1.1.5'
)
