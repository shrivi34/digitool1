TEST_THEME_LABEL = 'test theme label'
TEST_THEME_LABEL_EDITED = 'test theme label edited'
