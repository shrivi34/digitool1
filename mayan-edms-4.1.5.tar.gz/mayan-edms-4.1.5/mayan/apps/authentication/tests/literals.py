TEST_EMAIL_AUTHENTICATION_BACKEND = 'mayan.apps.authentication.auth.email_auth_backend.EmailAuthBackend'
