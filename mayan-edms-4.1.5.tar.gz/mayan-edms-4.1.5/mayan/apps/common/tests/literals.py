TEST_OBJECT_LABEL = 'test object label'
