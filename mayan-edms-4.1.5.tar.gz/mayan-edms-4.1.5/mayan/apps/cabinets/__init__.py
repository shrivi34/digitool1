default_app_config = 'mayan.apps.cabinets.apps.CabinetsApp'
