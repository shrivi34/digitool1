default_app_config = 'mayan.apps.dependencies.apps.DependenciesApp'
