default_app_config = 'mayan.apps.common.apps.CommonApp'
