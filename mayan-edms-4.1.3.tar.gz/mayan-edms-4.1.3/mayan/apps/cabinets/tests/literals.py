TEST_CABINET_LABEL = 'test cabinet label'
TEST_CABINET_LABEL_EDITED = 'test cabinet edited label'
TEST_CABINET_CHILD_LABEL = 'test cabinet child label'
