default_app_config = 'mayan.apps.databases.apps.DatabasesApp'
