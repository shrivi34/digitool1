default_app_config = 'mayan.apps.document_indexing.apps.DocumentIndexingApp'
