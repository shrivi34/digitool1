default_app_config = 'mayan.apps.dashboards.apps.DashboardsApp'
