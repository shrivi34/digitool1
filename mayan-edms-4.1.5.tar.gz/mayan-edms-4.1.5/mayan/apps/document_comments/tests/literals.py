TEST_COMMENT_TEXT = 'test comment text'
TEST_COMMENT_TEXT_EDITED = 'test comment text edited'
