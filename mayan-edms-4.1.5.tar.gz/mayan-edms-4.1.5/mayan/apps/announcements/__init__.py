default_app_config = 'mayan.apps.announcements.apps.AnnouncementsApp'
