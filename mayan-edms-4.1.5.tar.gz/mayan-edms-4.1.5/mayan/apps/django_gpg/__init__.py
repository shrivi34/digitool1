default_app_config = 'mayan.apps.django_gpg.apps.DjangoGPGApp'
